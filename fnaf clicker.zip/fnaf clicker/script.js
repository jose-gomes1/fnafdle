const animatronics = [
    { name: "Bonnie the Bunny", cost: 30, pps: 1, img: "images/bonnie.png" },
    { name: "Chica the Chicken", cost: 200, pps: 5, img: "images/chica.png" },
    { name: "Foxy the Pirate", cost: 500, pps: 15, img: "images/foxy.png" },
    { name: "Freddy Fazbear", cost: 1000, pps: 50, img: "images/freddy.png" },
    { name: "Golden Freddy", cost: 5000, pps: 100, img: "images/golden.png" },
    { name: "The Mimic Endo", cost: 7500, pps: 250, img: "images/mimic.png" },
    { name: "Springtrap .", cost: 20000, pps: 500, img: "images/springtrap.png" } 
];

let pizzaCount = 0;
let pizzasPerSecond = 0;

const pizzaElement = document.getElementById("pizza");
const pizzaCountElement = document.getElementById("pizza-count");
const ppsElement = document.getElementById("pps");
const animatronicsContainer = document.getElementById("animatronics");
const animatronicDisplay = document.getElementById("animatronic-display");

pizzaElement.addEventListener("mouseover", () => {
    pizzaElement.style.transform = "scale(0.8)"; // Shrink on hover
});

pizzaElement.addEventListener("mouseout", () => {
    pizzaElement.style.transform = "scale(1)"; // Reset size when mouse leaves
});

pizzaElement.addEventListener("click", () => {
    pizzaCount++;  // Increment pizza count
    updateDisplay();  // Update the display with the new pizza count
}); 


function updateDisplay() {
    pizzaCountElement.textContent = Math.floor(pizzaCount);
    ppsElement.textContent = pizzasPerSecond;
}

function createAnimatronicButtons() {
    animatronics.forEach((animatronic, index) => {
        const animatronicDiv = document.createElement("div");
        animatronicDiv.className = "animatronic";

        const animatronicName = document.createElement("h3");
        animatronicName.textContent = animatronic.name;

        const animatronicCost = document.createElement("p");
        animatronicCost.textContent = `Cost: ${animatronic.cost} slices`;
        
        const animatronicPPS = document.createElement("p");
        animatronicPPS.textContent = `Slices per Second: ${animatronic.pps}`;

        const buyButton = document.createElement("button");
        buyButton.textContent = "Buy";
        buyButton.addEventListener("click", () => buyAnimatronic(index));
        
        animatronicDiv.appendChild(animatronicName);
        animatronicDiv.appendChild(animatronicCost);
        animatronicDiv.appendChild(animatronicPPS);
        animatronicDiv.appendChild(buyButton);

        animatronicsContainer.appendChild(animatronicDiv);
    });
}

function buyAnimatronic(index) {
    const animatronic = animatronics[index];

    if (pizzaCount >= animatronic.cost) {
        pizzaCount -= animatronic.cost;
        pizzasPerSecond += animatronic.pps;
        animatronic.cost = Math.ceil(animatronic.cost * 1.2); // Increase cost
        if (!animatronic.owned) {
            displayAnimatronic(animatronic.img);
            animatronic.owned = true;
        }
        triggerConfetti(event);  // Trigger confetti where the click happens
        updateDisplay();
        updateAnimatronicButtons();
    }
}

function displayAnimatronic(imgUrl) {
    const animatronicImg = document.createElement("img");
    animatronicImg.src = imgUrl;
    animatronicDisplay.appendChild(animatronicImg);
}

function updateAnimatronicButtons() {
    const animatronicDivs = document.querySelectorAll(".animatronic");
    animatronics.forEach((animatronic, index) => {
        const costElement = animatronicDivs[index].querySelector("p:nth-of-type(1)");

        costElement.textContent = `Cost: ${animatronic.cost} pizzas`;
    });
}

function generatePizzas() {
    pizzaCount += pizzasPerSecond / 10;
    updateDisplay();
}

createAnimatronicButtons();
setInterval(generatePizzas, 100); // Generate pizzas every 100ms
